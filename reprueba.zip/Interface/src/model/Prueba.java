
package model;

import java.time.LocalDate;

public abstract class Prueba implements Aprobable {
    
    protected final LocalDate fechaFinalizacion;

    public Prueba(final LocalDate fechaFinalizacion) {
        this.fechaFinalizacion = fechaFinalizacion;
    }

    public final LocalDate getFechaFinalizacion() {
        return fechaFinalizacion;
    }
}
    

