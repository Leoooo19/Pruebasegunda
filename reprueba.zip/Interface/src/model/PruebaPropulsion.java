package model;

import java.time.LocalDate;


public final class PruebaPropulsion extends Prueba {
    public static final int LIMITE_DURACION = 90;
    public static final int NOTA_MINIMA = 0;
    public static final int NOTA_MAXIMA = 10;
    public static final int NOTA_MINIMA_APROBACION = 6;

    private final int duracion;
    private final int puntaje;

    public PruebaPropulsion(final LocalDate fecha, final int duracion, final int puntaje) {
        super(fecha);
        this.duracion = duracion;
        this.puntaje = puntaje;
    }

    @Override
    public final boolean aprobo() {
        return duracion <= LIMITE_DURACION && puntaje >= NOTA_MINIMA_APROBACION;
    }
}
