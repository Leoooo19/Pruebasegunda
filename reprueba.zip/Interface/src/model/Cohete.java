
package model;


public class Cohete {
    
    private static final int INITIAL_ID = 50000;
    private static int id;
    private static String nombre;
    
                
    
    
   
    
    
    
    
    
}
