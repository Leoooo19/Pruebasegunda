/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.time.LocalDate;

public final class PruebaSistemas extends Prueba {
    private final NivelEvaluacion nivelEvaluacion;

    public PruebaSistemas(final LocalDate fecha, final NivelEvaluacion nivel) {
        super(fecha);
        this.nivelEvaluacion = nivel;
    }

    @Override
    public final boolean aprobo() {
        return nivelEvaluacion == NivelEvaluacion.ACEPTABLE || nivelEvaluacion == NivelEvaluacion.EXCELENTE;
    }
}
  

