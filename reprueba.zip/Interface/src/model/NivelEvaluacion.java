
package model;


public enum NivelEvaluacion {
    
   DEFICIENTE,
   ACEPTABLE,
   EXCELENTE

}
