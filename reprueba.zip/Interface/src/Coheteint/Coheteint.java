/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Coheteint;

import java.time.LocalDate;

public final class Main {
    public static void main(final String[] args) {
        final EmpresaAeroEspacial empresa = new EmpresaAeroEspacial("SpaceX");

        final Cohete c1 = new Cohete("Falcon");
        c1.agregarPrueba(new PruebaPropulsion(LocalDate.now(), 85, 7));
        c1.agregarPrueba(new PruebaSistemas(LocalDate.now(), NivelEvaluacion.EXCELENTE));

        final Cohete c2 = new Cohete("Starship");
        c2.agregarPrueba(new PruebaPropulsion(LocalDate.now(), 100, 5)); // no pasa
        c2.agregarPrueba(new PruebaSistemas(LocalDate.now(), NivelEvaluacion.DEFICIENTE));

        empresa.agregarCohete(c1);
        empresa.agregarCohete(c2);

        System.out.println("Cohetes listos para lanzar: " + empresa.cantListosParaLanzar());
    }
}